function [x_opt,v_opt,iter,time]=TRAPEZOID05(c,d,Q,P,A,b,err,act)
%% Find a globally optimal solution of WCLO problem
%                       max \sum(P'*x+c)/(Q'x+d)
%                       s.t. A*x<=b,x>=0,
%Trapezoid BB Algorithm
tstart=tic;
[n,r]=size(Q);
xub=ones(n,1);
sl0=zeros(r,1);
tl0=zeros(r,1);
wl0=zeros(r,1);
wu0=zeros(r,1);
for i=1:r
    [~,wl0(i)]=cplexlp(P(:,i)'+Q(:,i)',A,b,[],[],zeros(n,1),xub);
    [~,wu0(i)]=cplexlp(-P(:,i)'-Q(:,i)',A,b,[],[],zeros(n,1),xub);
end
wu0=-wu0;
wl0=wl0+c'+d;
wu0=wu0+c'+d;
[ra, ca] = size(A);
for i=1:r
    %         sl0(i)=c(i)/(wu0(i)-d(i));
    %         tl0(i)=(wu0(i)-d(i))/c(i);
    [X_u, fval_u] = cplexlp([-P(:, i)' -c(i)], [A -b], zeros(ra, 1), [Q(:, i)' d(i)], 1, [zeros(n, 1); err], ones((n + 1), 1) * inf);
    y_u = X_u(1 : n);
    t_u = X_u(n + 1);
    x_u = y_u /t_u;
    val_u = initialProblem(Q, P, c, d, r, x_u);
    arr.x = x_u;
    tl0(i) = -fval_u;
    [X_l, fval_l] = cplexlp([P(:, i)' c(i)], [A -b], zeros(ra, 1), [Q(:, i)' d(i)], 1, [zeros(n , 1); err], ones((n + 1), 1) * inf);
    y_l = X_l(1 : n);
    t_l = X_l(n + 1);
    x_l = y_l / t_l;
    sl0(i) = fval_l;
end
sl=sl0;
tl=tl0;
[x,y,lb,ub,~]=Upper_bound(c',d,Q,P,A,b,sl0,tl0,wl0,wu0,xub);
eta=P'*x+c';
xi=Q'*x+d;
yy=y;%
for i=1:size(y,1)
    if sl(i)<eta(i)/xi(i)&&eta(i)/xi(i)<tl(i)
        y(i)=((sl(i)+tl(i)+1)*eta(i)-sl(i)*tl(i)*xi(i))/(xi(i)+eta(i));
    end
end
UB=sum(y);
x_opt=x;
y_opt=y;
v_opt=lb;
AllNodes = [];
OptNodes=[];
prob.x=x;
prob.y=y;
prob.ub=ub;
prob.UB=UB;
prob.sl0=sl0;
prob.tl0=tl0;
prob.dist=yy-eta./xi;%
prob.w=eta./xi;
iter=0;
MaxIter=10000;
MaxTime=3600;
print=1;
 if print == 1
     fprintf(1,'Iter = %3d,  ub = %12.8f, UB = %12.8f, LB = %12.8f, gap = %5.2f%%\n',...
         iter,ub,UB,v_opt,100*abs(v_opt-UB)/(1.0e-10+abs(v_opt)));
 end
% disp(prob.x');
%        fprintf(1,'%8d %8.5f %8.5f %8.5f ',...
%          iter,ub,UB,v_opt);
%fprintf(fid,'k & LB & vk   & vk1   & vk2 \n');
while iter < MaxIter && toc(tstart) < MaxTime   && abs(UB-v_opt) > err && abs(v_opt-UB)/(1.0e-10+abs(v_opt))>1e-7
    %partition
    iter = iter+1;
    if UB-v_opt>err
        subprob{1} = prob;
        subprob{2} = prob;
        [~,i_max] = max(prob.dist);
        if act=='w'
            midpoint=prob.w(i_max);
        else
            midpoint=(prob.sl0(i_max)+prob.tl0(i_max))/2;
        end
        subprob{1}.sl0(i_max)=midpoint;%prob.y(i_max);%
        subprob{2}.tl0(i_max)=midpoint;%prob.y(i_max);%
        for ii=1:2
            %disp(subprob{ii}.sl0');
            %disp(subprob{ii}.tl0');
            [x0,y0,lb,ub,~]=Upper_bound(c',d,Q,P,A,b,subprob{ii}.sl0,subprob{ii}.tl0,wl0,wu0,xub);
            yy=y0;
            if ~isempty(x0) && ~isempty(y0) 
                eta=P'*x0+c'; 
                xi=Q'*x0+d;
                for i=1:size(y0,1)
                    if subprob{ii}.sl0(i)<eta(i)/xi(i)&&eta(i)/xi(i)<subprob{ii}.tl0(i)
                        y0(i)=((subprob{ii}.sl0(i)+subprob{ii}.tl0(i)+1)*eta(i)-subprob{ii}.sl0(i)*subprob{ii}.tl0(i)*xi(i))/(xi(i)+eta(i));
                    end
                end
                UB=sum(y0);
                subprob{ii}.dist=yy-eta./xi;
                subprob{ii}.ub = ub;
                subprob{ii}.UB = UB;
                subprob{ii}.y = y0;
                subprob{ii}.x = x0;
                subprob{ii}.w=eta./xi;         
                fprintf('x%d%d',iter,ii);
                disp(subprob{ii}.x');
                fprintf('ub%d%d',iter,ii);
                disp(subprob{ii}.ub);
                fprintf('UB%d%d',iter,ii);
                disp(subprob{ii}.UB);
                % update lower bound
                if lb > v_opt
                   v_opt = lb;
                   x_opt = x0;
                   y_opt = y0;
                end
                %disp(subprob{ii}.ub);%---
               %sum(subprob{ii}.dist)
                if sum(subprob{ii}.dist) > err
                    AllNodes = [AllNodes,subprob{ii}];
                end
            end
        end
    end
%    fprintf(fid,'\n');
    %% delete nodes
    if ~isempty(AllNodes)
        ii = 0;
        while ii < length(AllNodes)
            ii = ii+1;
            if AllNodes(ii).ub<v_opt+err
                AllNodes(ii) = [];
                ii = ii-1;
            end
        end
    end
    if isempty(AllNodes)
        fprintf(2,'AllNodes = empty!\n');
        break;
    else
        ub = AllNodes(1).ub;
        UB = AllNodes(1).UB;
        index_LB = 1;
        ii = 1;
        while ii < length(AllNodes)
            ii = ii+1;
            if AllNodes(ii).ub > ub
                UB = AllNodes(ii).UB;
                ub = AllNodes(ii).ub;
                index_LB = ii;
            end
        end
        prob = AllNodes(index_LB);
        %         fprintf(1,'norm = %.8f, err = %.8f\n',norm(prob.tub-prob.tlb)^2/4,err);
        AllNodes(index_LB) = [];
    end
%     if mod(iter,1) == 0 && print == 1
%         fprintf(1,'Iter = %3d,  UB = %12.8f,  LB = %12.8f, gap = %5.2f%%\n',...
%             iter,UB,v_opt,100*abs(v_opt-UB)/(1.0e-10+abs(v_opt)));
%     end
 if print == 1
     fprintf(1,'Iter = %3d,  ub = %12.8f, UB = %12.8f, LB = %12.8f, gap = %5.2f%%\n',...
         iter,ub,UB,v_opt,100*abs(v_opt-UB)/(1.0e-10+abs(v_opt)));
 end
end
x_opt = prob.x;%x_opt(:,1);
y_opt = prob.y;%y_opt(:,1);
% fprintf('x:');
 if print == 1
     fprintf(1,'Iter = %3d,  ub = %12.8f, UB = %12.8f, LB = %12.8f, gap = %5.2f%%\n',...
         iter,ub,UB,v_opt,100*abs(v_opt-UB)/(1.0e-10+abs(v_opt)));
 end
%disp(prob.x');
% if print == 1
%     fprintf(1,'Iter = %3d,  UB = %12.8f,  LB = %12.8f, gap = %5.2f%%\n',...
%         iter,UB,v_opt,100*(UB-v_opt)/(1.0e-10+abs(v_opt)));
% end
time = toc(tstart);
end