function [Q,P,c,d,A,b]=generate_data(m,n,r)
nA=m;
Q=0.5*rand(n,r);
P=-0.5*rand(n,r);
c=-(8)*rand(1,r)-2;%-10*ones(1,r);%
A=rand(nA,n);  
b=ones(nA,1);%0.5*sum(max(0,A),2) + rand(size(A,1),1);
d=-c';%(5)*rand(1,r)';
%d=d';
end