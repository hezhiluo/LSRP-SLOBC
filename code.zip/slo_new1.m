function [x_opt,y_opt,fval,iter,time]=slo_new1(c,d,Q,P,yl,yu,A,b,x0,xub)
%max P'x_y+y_P'x-y_P'x_+c'*y
% s.t. A*x<=b,
%     0<=x<=1,y\in[yl,yu]
%x,y
err=1.0e-5;
[n,r]=size(P);
y0=1./(Q'*x0+d);
MaxIter=30;
MaxTime=300;
tstart = tic;
xub = inf * ones(n, 1);
lb=[zeros(n,1);yl];
ub=[xub;yu];
iter=0;
while iter<MaxIter && toc(tstart) < MaxTime
    iter=iter+1;
    xbar = x0;
    ybar = y0;
    f=[ybar'*P',xbar'*P+c];
    Aeq=[diag(ybar)*Q',diag(Q'*xbar)+diag(d)];
    beq=[ones(r,1)+ybar.*(Q'*xbar)];
    [X,val,exitflag]=cplexlp(-f,[A,zeros(size(A,1),r);Aeq],[b;beq],[],[],lb,ub);
    if exitflag ~= 1
        fprintf(2,'\nExist in SLO:\n');
        fprintf(2,'exitflag = %.2f,  ',exitflag);
        x_opt=[];
        y_opt=[];
        fval=inf;
        time=toc(tstart);
        break;
    end
    x=X(1:n);
    y=1./(Q'*x+d);
    f0 = (xbar' * P + c) * y0 + ybar' * P' * x0;
    fk = (xbar' * P + c) * y + ybar' * P' * x;
    if(fk - f0 <= err)
        x_opt=x0;
        y_opt=y0;
        fval=-y_opt'*P'*x_opt-c*y_opt;
        time=toc(tstart);
        break;
    end
    uk = (y - y0)' * P' * (x - x0);
    vk = y0' * P' * (x - x0) + (y - y0)' * (P' * x0 + c');
    tauk = y0' * (P' * x0 + c');
    phi_0 = tauk;
    phi_1 = uk + vk + tauk;
    if uk < 0
        lambdak = max(0, min(1, -vk / (2 * uk)));
    elseif uk >= 0 && phi_0 > phi_1
        lambdak = 0;
    else
        lambdak = 1;
    end
    phi_k = uk * (lambdak ^ 2) + vk * lambdak + tauk;
    x0 = x0 + lambdak * (x - x0);
    y0 = 1./(Q' * x0 + d);
    time=toc(tstart);
end
end