The codes are used to test the methods presented in "A New Branch-and-Cut Algorithm for Linear Sum-of-Ratios
Problem" , which has been submitted to Mathematical Programming Computation.

The codes are organized as follows.

The key parameters in the program "generate_data.m" include:
  m  --    the number of linear constraints, which equals to n/4
  
  n  --    the number of variables, which should be divided by 4
  
  r  --    the number of ratios
  
The program "generate_data.m" will generate different size of problems by setting different key parameters.

Two main testing programs are "test_scobb_YF_trapezoid.m" and "test_baron.m".

"test_scobb_YF_trapezoid.m" is used to test SLOBC, BB-QCR and TBB simultaneously. You can also comment out some parts of the program to run one specific algorithm.

"test_baron.m" is the program which calls BARON to solve problems.

Before running the testing programs, you need to check out the following tips. 

Firstly, MATLAB, BARON and CPLEX should be installed in advance. Beyond that, the path of the interface of Cplex for Matlab should be added to the search path of Matlab. 

Secondly, all of the given programs should be added to the search path of MATLAB.
 
Thirdly, the paths of the input data and the output files should be changed correctly, referring to the rules of MATLAB.

For instance, if you want to obtain the average results of 1 example, which has 500 variables, 125 linear constraints and 3 ratios, for SLOBC, BB-QCR and TBB,  you can do it as follows

-- Set n = 500, m = 125, r = 3 and run "generate_data.m". Save the data in the right path and name the data after "data_500_3_1".

-- Make sure the output path does exist.
  
-- Run "test_scobb_YF_trapezoid.m" in the Command Window.
  
-- The computing results will be saved in the output path.

For more details, please read two testing programs and other subprograms.