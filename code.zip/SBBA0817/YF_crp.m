function [optx,val,tttt]=YF_crp(lw1,uw1)%����cplex������׶�ɳ���������Ž�����ֵ
global p n m c d e f A b
y=sdpvar(n,1);
t1=sdpvar(1,1);
r=sdpvar(p-1,1);
w=sdpvar(p-1,1);
v=sdpvar(p-1,1);
Con=[];
for i=1:p-1
    Con=[Con,A*y<=t1.*b,y>=0,y<=ones(n,1).*t1,t1>=0,e(p,:)*y+t1.*f(p)==1,
        r(i)+(e(i,:)*y+t1*f(i))==2*w(i),
        r(i)-(e(i,:)*y+t1*f(i))==2*v(i),
        lw1(i)<=w(i)<=uw1(i);
        c(i,:)*y+d(i)*t1+v(i)*v(i)<=(lw1(i)+uw1(i))*w(i)-lw1(i)*uw1(i)];
end
ops = sdpsettings('verbose',0,'solver','cplex');
FFF=sum(r)+c(p,:)*y+t1.*d(p);
sol = optimize(Con,FFF,ops);
tttt=sol.problem;
% if reuslt.problem == 0 % problem =0 �������ɹ�
opty=value(y);
optt1=value(t1);
% fprintf('y_hat:\n');
% disp(opty');
% fprintf('z_hat:\n');
% disp(-value(r)');
% fprintf('t_hat:\n');
% disp(optt1);
optx=opty./ optt1;
val=value(FFF);
end% ��ת
% else
%     disp('������');
% end

