function [L,U]=YF_zlu()%��������������z�����½�  %�������г���
global p n m c d e f A b
% y = sdpvar(n,1);
% t=sdpvar(1,1);
% Con=[A*y<=t.*b,y>=0,t>0,e(p,:)*y+t.*f(p,:)==1];
% ops = sdpsettings('verbose',0,'solver','cplex');
% for i=1:p
%   FFF(i)=e(i,:)*y+t.*f(i); 
%   reuslt = optimize(Con,FFF(i));
%     ll1(i)=value(FFF(i));
%     FFFu(i)=-(e(i,:)*y+t.*f(i));
%   reuslt1 = optimize(Con,FFFu(i));
%     uu1(i)=-value(FFFu(i));
%     L(i)=ll1(i);
%     U(i)=uu1(i);
% end
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
AA=[A -b;e(p,:) f(p,:);-e(p,:) -f(p,:)];
bb=[zeros(m,1);1;-1];
F=[e f];
lb=zeros(n+1,1);
for i=1:p-1
   [~,fval1]=cplexlp(F(i,:)',AA,bb,[],[],lb);
   ll1(i)=fval1;
   [~, fval2]=cplexlp(-F(i,:)',AA,bb,[],[],lb);
  uu1(i)=-fval2;
  L(i)=ll1(i);
  U(i)=uu1(i);
end
end