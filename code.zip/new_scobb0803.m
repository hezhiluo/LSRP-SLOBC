function [x_opt,v_opt,iter,time,v_slo,time_slo,iter_slo,N_sco,t_nsco]=new_scobb0803(c,d,Q,P,A,b,err,act)
%% Find a globally optimal solution of WCLO problem
%                       min \sum(P'*x+c)/(Q'x+d)
%                       s.t. A*x<=b,x>=0,
%by SLOBB Algorithm
%% It is equivalent to the dual problem:
%          max f(u,y):=u'*Q'*y+b0'*y

%           s.t. A'*y<=c,y<=0
%                u \in K
%A\in R^m; u\in R^r;  e_i\in R^r;  Q^{m*r}
N_sco=0;
t_nsco=0;
print = 1;
kk=1;
tstart = tic;
[n,r]=size(Q);
xub=ones(n,1);
yl0=zeros(r,1);
yu0=zeros(r,1);
Set_x=[];
for i=1:r
    [~,ya]=cplexlp(-Q(:,i)',A,b,[],[],zeros(n,1),xub);
    [~,yb]=cplexlp(Q(:,i)',A,b,[],[],zeros(n,1),xub);
    yl0(i)=1/(d(i)-ya);
    yu0(i)=1/(d(i)+yb);
end
wl0=zeros(r,1);
wu0=zeros(r,1);
for i=1:r
    [x_sl0,wl0(i)]=cplexlp(P(:,i)'+Q(:,i)',A,b,[],[],zeros(n,1),xub);
    [x_tl0,wu0(i)]=cplexlp(-P(:,i)'-Q(:,i)',A,b,[],[],zeros(n,1),xub);
    Set_x=[Set_x,x_sl0,x_tl0];
end
wu0=-wu0;
wl0=wl0+c'+d;%u
wu0=wu0+c'+d;%v
[ra, ~] = size(A);
for i=1:r
    [X_u, fval_u] = cplexlp([-P(:, i)' -c(i)], [A -b], zeros(ra, 1), [Q(:, i)' d(i)], 1, [zeros(n, 1); err], ones((n + 1), 1) * inf);
    y_u = X_u(1 : n);
    t_u = X_u(n + 1);
    x_u = y_u / t_u;
    tl1(i) = -fval_u;
    [X_l, fval_l] = cplexlp([P(:, i)' c(i)], [A -b], zeros(ra, 1), [Q(:, i)' d(i)], 1, [zeros(n , 1); err], ones((n + 1), 1) * inf);
    y_l = X_l(1 : n);
    t_l = X_l(n + 1);
    x_l = y_l / t_l;
    Set_x = [Set_x, x_l, x_u];
    sl1(i) = fval_l;
end
sl0 = sl1';%alpha
tl0 = tl1';%beta
[x,y,~,~,~]=newUpper_bound(c',d,Q,P,A,b,sl0,tl0,wl0,wu0,xub,[]);
Set_x=[Set_x,x];
eta=P'*x+c';
xi=Q'*x+d;
ub=sum(y);
x_opt=x;
y_opt=y;
UB=ub;
AllNodes = [];
prob.x=x;
prob.y=y;
prob.ub=ub;
prob.sl0=sl0;
prob.tl0=tl0;
prob.dist=y-eta./xi;
prob.w=eta./xi;
prob.eta=eta;
prob.xi=xi;
t1=tic;
x0=mean(Set_x,2);
[x1,y1,v1,iter_slo,~]=slo_new1(c,d,Q,P,yl0,yu0,A,b,x0,xub);
time_slo=toc(t1);
v_opt = -v1; %% best lower bound
v_slo=v_opt;

iter=0;
MaxIter=10000;
MaxTime=3600;
if print == 1
    fprintf(1,'Iter = %3d,  UB = %12.8f,  LB = %12.8f, gap = %5.2f%%\n',...
        iter,UB,v_opt,100*abs(v_opt-UB)/(1.0e-10+abs(v_opt)));
end
while iter < MaxIter && toc(tstart) < MaxTime   && abs(v_opt-UB) > 1e-5 && abs(v_opt-UB)/(1.0e-10+abs(v_opt))>1e-6
    %% partition
    subprob{1} = prob;
    subprob{2} = prob;
    [~,i_max] = max(prob.dist);
    if act=='w'
        midpoint=prob.w(i_max);
    else
        midpoint=(prob.sl0(i_max)+prob.tl0(i_max))/2;
    end
    subprob{1}.sl0(i_max)=midpoint;
    subprob{2}.tl0(i_max)=midpoint;
    y2=prob.y;
    for i=1:size(y2,1)
        if y2(i)-prob.eta(i)/prob.xi(i)>0
            y2(i)=((prob.sl0(i)+prob.tl0(i)+1)*prob.eta(i)-prob.sl0(i)*prob.tl0(i)*prob.xi(i))/(prob.xi(i)+prob.eta(i));
        end
    end
    vbar = sum(y2);
    if v_opt <= vbar && vbar <= v_opt + err
        UB = vbar;
        iter=iter+1;
        break
    elseif vbar < v_opt
        tau = prob.ub;
    else
        tau = vbar;
    end
    iter = iter+1;
    for ii=1:2
        [x0,y0,lb,ub,~]=newUpper_bound(c',d,Q,P,A,b,subprob{ii}.sl0,subprob{ii}.tl0,wl0,wu0,xub,tau);
        if ~isempty(x0) %&& ~isempty(y0)
            eta=P'*x0+c';
            xi=Q'*x0+d;
            subprob{ii}.dist=y0-eta./xi;
            subprob{ii}.ub = ub;
            subprob{ii}.y = y0;
            subprob{ii}.x = x0;
            subprob{ii}.w=eta./xi;
            subprob{ii}.eta=eta;
            subprob{ii}.xi=xi;
            v = lb;
            AllNodes = [AllNodes,subprob{ii}];
        end
    end
                    %% restart SCO
     if initialProblem( Q, P, c', d, r, subprob{1}.x)>initialProblem( Q, P, c', d, r, subprob{2}.x)
         x0=subprob{1}.x;
         ff=initialProblem( Q, P, c', d, r, subprob{1}.x);
     else
         x0=subprob{2}.x;
         ff=initialProblem( Q, P, c', d, r, subprob{2}.x);
     end
     if ff > v_opt+1.0e-10%0.001*abs(v_opt)
         N_sco=N_sco+1;
         [x1,y1,v1,iter_slo,time_slo]=slo_new1(c,d,Q,P,yl0,yu0,A,b,x0,xub);
         t_nsco=t_nsco+time_slo;
         v1=-v1;
         if v1 > v_opt+1.0e-10
             fprintf(1,'Call SLO successfully!\n');
             v_opt = v1;
             x_opt = x1;
             y_opt = y1;
         else
             x_opt=x0;
             y_opt=y0;
         end
     end
    %% node deletion
    if ~isempty(AllNodes)
        ii = 0;
        while ii < length(AllNodes)
            ii = ii+1;
            if AllNodes(ii).ub < v_opt - err
                AllNodes(ii) = [];
                ii = ii-1;
            end
        end
    end
    if isempty(AllNodes)
        fprintf(2,'AllNodes = empty!\n')
        break;
    else
        UB = AllNodes(1).ub;
        index_LB = 1;
        ii = 1;
        while ii < length(AllNodes)
            ii = ii+1;
            if AllNodes(ii).ub > UB
                UB = AllNodes(ii).ub;
                index_LB = ii;
            end
        end
        prob = AllNodes(index_LB);
        AllNodes(index_LB) = [];  
    end
    if mod(iter,1) == 0 && print == 1
        fprintf(1,'Iter = %3d,  UB = %12.8f,  LB = %12.8f, gap = %5.2f%%\n',...
             iter,UB,v_opt,100*abs(v_opt-UB)/(1.0e-10+abs(v_opt)));
     end
     if prob.ub<=v_opt-err
         break;
     end
end
x_opt = prob.x;
y_opt = prob.y;
%gap=100*(UB-v_opt)/(1.0e-10+abs(v_opt));
if print == 1
    fprintf(1,'Iter = %3d,  UB = %12.8f,  LB = %12.8f, gap = %5.2f%%\n',...
        iter,UB,v_opt,100*(UB-v_opt)/(1.0e-10+abs(v_opt)));
end
time = toc(tstart);
fprintf('fval & iter & time & v_slo & time_slo & iter_slo & N_sco & t_nsco \n');
fprintf('%.7f & %.1f & %.4f & %.7f & %.4f & %.1f & %.2f & %.2f\n',v_opt, iter, time,v_slo,time_slo,iter_slo,N_sco,t_nsco);
end