function [x,y,lb,ub,time]=newUpper_bound(c,d,Q,P,A,b,sl0,tl0,wl0,wu0,xub,tau)
%%x\in R^n,y\in R^r.
x=[];
y=[];
ub=inf;
lb=-inf;
tstart = tic;
[n,r]=size(Q);
Aineq=[];
bineq=[];
alpha=(tl0+1).*(c-sl0.*d)+sl0.*wl0;
beta=(sl0+1).*(c-tl0.*d)+tl0.*wu0;
f=[zeros(1,n),ones(1,r)];
LB=[zeros(n,1);-inf*ones(r,1)];
UB=[xub;inf*ones(r,1)];
Aineq=[Aineq;A,zeros(size(A,1),r)];
bineq=[bineq;b];
Aineq=[Aineq;diag(tl0+1)*(sl0'.*Q-P)',diag(wl0)];
Aineq=[Aineq;diag(sl0+1)*(tl0'.*Q-P)',diag(wu0)];
bineq=[bineq;alpha;beta];
Aineq=[Aineq;(sl0'.*Q-P)',zeros(r);(P-tl0'.*Q)',zeros(r)];
bineq=[bineq;c-sl0.*d;tl0.*d-c];
if ~isempty(tau)
    Aineq=[Aineq;zeros(1,n),ones(1,r)];
    bineq=[bineq;tau];
end
[X,fval,exist]=cplexlp(-f,Aineq,bineq,[],[],LB,UB);
if(exist>0)
    x=X(1:n);
    y=X(n+1:end);
    ub=-fval;
    y_hat=1./(Q'*x+d);
    lb=y_hat'*(P'*x+c);
end
time=toc(tstart);
end