function test_scobb_YF_trapezoid()
clear
clc
warning('off');
nx1=[500,600,800,1000,1200,1500,1800,2000,2500,3000,3500,4000];
nx2=[500,600,800,1000,1200,1500,1800,2000,2500,3000];
nx3=[500,600,800,1000,1200,1500,1800,2000,2500];
nx4=[500,600,800,1000,1200,1500,1800,2000];
%nx4=[1500,1800,2000];
nr=[7];
% nr=7;
err=1.0e-5;
row = 0;
for j=1:length(nr)
    r=nr(j);
    if r == 3
        nx = nx1;
    elseif r == 5
        nx = nx2;
    elseif r == 6 || r== 7
        nx = nx3;
    elseif r == 8
        nx = nx4;
    end
    for i=1:length(nx)
        n=nx(i);
        result1=[];
        result2=[];
        result3=[];
        tk=0;
        for k=1:10
            file_name = sprintf('F:/program/slpr_code0627/data0804/data_%d_%d_%d',n,r,k);
            [~,errmsg]=fopen([file_name,'.mat']);
            if isempty(errmsg)==0
                continue;
            end
            tk=tk+1;
            data = load(file_name);
            A = data.A;
            b = data.b;
            c = data.c;
            d = data.d;
            P = data.P;
            Q = data.Q;
            [row, ~] = size(A);
            time1 = tic;
            [~,v_opt1,iter1,time1,v_slo1,time_slo1,iter_slo1,N_sco1,t_nsco1]=new_scobb0803(-c,d,Q,-P,A,b,err,'w');
            result1 = [result1; v_opt1, iter1, time1,v_slo1,time_slo1,iter_slo1,N_sco1,t_nsco1];
            time2 = tic;
            [~,v_opt2,iter2,time2]=YF_main(0,0,0,P',c',Q',d,A,b);
            result2 = [result2; v_opt2, iter2, time2];
            time3=tic;
            [~,v_opt3,iter3,time3]=TRAPEZOID02(-c,d,Q,-P,A,b,err,'w');
            result3 = [result3; v_opt3, iter3, time3];            
        end
        ave1 = mean(result1);
        result1 = [ave1; result1];
        dir1 = sprintf('result0819_scobb/result_%d_%d_%d',r,n,row);
        fid1=fopen(['F:/program/slpr_code0627/',dir1,'.txt'],'wt');
        save(['F:/program/slpr_code0627/',dir1,'.txt'],'result1');
        fprintf(fid1, 'fval & iter & time & v_slo & time_slo & iter_slo & N_sco & t_nsco \n');
        fprintf(fid1,'%.7f & %.1f & %.4f & %.7f & %.4f & %.1f & %.2f & %.2f\n',result1(1,:));
        for kk=2:tk+1
            fprintf(fid1,'%.7f & %.1f & %.4f & %.7f & %.4f & %.1f & %.2f & %.2f\n',result1(kk,:));
        end
        fclose(fid1);
        ave2 = mean(result2);
        result2 = [ave2; result2];
        dir2 = sprintf('result0819_YF/result_%d_%d_%d',r,n,row);
        fid2=fopen(['F:/program/slpr_code0627/',dir2,'.txt'],'wt');
        save(['F:/program/slpr_code0627/',dir2,'.txt'],'result2');
        fprintf(fid2, 'fval & iter &time\n');
        fprintf(fid2,'%.7f & %.1f & %.4f\n',result2(1,:));
        for kk=2:tk + 1
            fprintf(fid2,'%.7f & %.1f & %.4f\n',result2(kk,:));
        end
        fclose(fid2);    
        ave3 = mean(result3);
        result3 = [ave3; result3];
        dir3 = sprintf('result0819_trapezoid02/result_%d_%d_%d',r,n,row);
        fid3=fopen(['F:/program/slpr_code0627/',dir3,'.txt'],'wt');
        save(['F:/program/slpr_code0627/',dir3,'.txt'],'result3');
        fprintf(fid3, 'fval & iter &time\n');
        fprintf(fid3,'%.7f & %.1f & %.4f\n',result3(1,:));
        for kk=2:tk + 1
            fprintf(fid3,'%.7f & %.1f & %.4f\n',result3(kk,:));
        end
        fclose(fid3);        
    end
end
end