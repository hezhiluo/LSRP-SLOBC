function test_baron()
clear
clc
warning('off');
%nx1=[500,600,800,1000,1200,1500,1800,2000,2500,3000,3500,4000];
nx1=[800,1000,1200,1500,1800,2000,2500,3000,3500,4000];
nx2=[500,600,800,1000,1200,1500,1800,2000,2500,3000];
nx3=[500,600,800,1000,1200,1500,1800,2000,2500];
nx4=[500,600,800,1000,1200,1500,1800,2000];
nr=[5];
err=1.0e-5;
row = 0;
for j=1:length(nr)
    r=nr(j);
    if r == 3
        nx = nx1;
    elseif r == 5
        nx = nx2;
    elseif r == 6 || r== 7
        nx = nx3;
    elseif r == 8
        nx = nx4;
    end
    for i=1:length(nx)
        n=nx(i);
        result=[];
        for k=1:10
            file_name = sprintf('F:/program/slpr_code0627/data0804/data_%d_%d_%d',n,r,k);
            data = load(file_name);
            A = data.A;
            b = data.b;
            c = data.c;
            d = data.d;
            P = data.P;
            Q = data.Q;
            [row, ~] = size(A);
            time = tic;
            [fval_baron, time_baron]=baron_p1(-c,d,Q,-P,A,b);
            %             [~,v2,iter2,time2]=TRAPEZOID(-c,d,Q,-P,A,b,1.0e-5,'w');
            %             result = [result; v2, iter2, time2];
          %  [~,v_opt,iter,time,v_slo,time_slo,N_sco,t_nsco]=new_scobb(-c,d,Q,-P,A,b,1.0e-5,'w');
            result = [result;fval_baron, time_baron];
        end
        ave = mean(result);
        result = [ave; result];
        dir = sprintf('result0819_baron/result_%d_%d_%d',r,n,row);
        fid=fopen(['F:/program/slpr_code0627/',dir,'.txt'],'wt');
        save(['F:/program/slpr_code0627/',dir,'.txt'],'result');
        fprintf(fid,'fval_baron & time_baron\n');
        fprintf(fid,'%.7f & %.2f\n',result(1,:));
        for kk=2:k + 1
            fprintf(fid,'%.7f & %.2f\n',result(kk,:));
        end
        fclose(fid);
    end
end
end