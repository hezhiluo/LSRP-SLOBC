function sum = initialProblem( Q, P, c, d, r, x)
sum = 0;
for i = 1 : r
    sum = sum + (P(:, i)' * x + c(i)) / (Q(:, i)' * x + d(i));
end
end

