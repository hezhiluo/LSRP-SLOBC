function [x_opt,v_opt,iter,time]=TRAPEZOID02(c,d,Q,P,A,b,err,act)
%% Find a globally optimal solution of WCLO problem
%                       max \sum(P'*x+c)/(Q'x+d)
%                       s.t. A*x<=b,x>=0,
%by SUMRATIO 02 Algorithm
tstart=tic;
[n,r]=size(Q);
xub=ones(n,1);
sl0=zeros(r,1);
tl0=zeros(r,1);
wl0=zeros(r,1);
wu0=zeros(r,1);
for i=1:r
    [~,wl0(i)]=cplexlp(P(:,i)'+Q(:,i)',A,b,[],[],zeros(n,1),xub);
    [~,wu0(i)]=cplexlp(-P(:,i)'-Q(:,i)',A,b,[],[],zeros(n,1),xub);
end
wu0=-wu0;
wl0=wl0+c'+d;%u
wu0=wu0+c'+d;%v
sl0=c'./(wu0-d);
tl0=(wu0-d)./c';   %large scale alpha and beta
% [ra, ~] = size(A);
% for i=1:r
%     [~, fval_u] = cplexlp([-P(:, i)' -c(i)], [A -b], zeros(ra, 1), [Q(:, i)' d(i)], 1, [zeros(n, 1); err], ones((n + 1), 1) * inf);
%     tl0(i) = -fval_u;%beta
%     [~, fval_l] = cplexlp([P(:, i)' c(i)], [A -b], zeros(ra, 1), [Q(:, i)' d(i)], 1, [zeros(n , 1); err], ones((n + 1), 1) * inf);
%     sl0(i) = fval_l;%alpha
% end                 %accurate alpha and beta
[x,y,lb,ub,~]=Upper_bound(c',d,Q,P,A,b,sl0,tl0,wl0,wu0,xub);
eta=P'*x+c';
xi=Q'*x+d;
% fprintf('x0: ');
% disp(x');
% fprintf('y0: ');
% disp(y');
% fprintf('v0: ');
% disp(ub);%---------------------------------------------------------------
x_opt=x;
y_opt=y;
v_opt=lb;
UB=ub;
AllNodes = [];
prob.x=x;
prob.y=y;
prob.ub=ub;
prob.sl0=sl0;
prob.tl0=tl0;
prob.dist=y-eta./xi;
prob.w=eta./xi;
iter=0;
MaxIter=10000;
MaxTime=3600;
print=1;
if print == 1
    fprintf(1,'Iter = %3d,  UB = %12.8f,  LB = %12.8f, gap = %5.2f%%\n',...
        iter,UB,v_opt,100*abs(v_opt-UB)/(1.0e-10+abs(v_opt)));
end
% fprintf(1,'%8d %8.5f %8.5f',...
%          iter,UB,v_opt);
while iter < MaxIter && toc(tstart) < MaxTime   && abs(v_opt-UB) > 1e-5 && abs(v_opt-UB)/(1.0e-10+abs(v_opt))>1e-6
    %partition
    iter = iter+1;
    subprob{1} = prob;
    subprob{2} = prob;
    [~,i_max] = max(prob.dist);
    if act=='w'
        midpoint=prob.w(i_max);
    else
        midpoint=(prob.sl0(i_max)+prob.tl0(i_max))/2;
    end
    subprob{1}.sl0(i_max)=midpoint;%prob.y(i_max);%
    subprob{2}.tl0(i_max)=midpoint;%prob.y(i_max);%
%     disp(roundn(prob.x',-5));
    for ii=1:2
        %disp(subprob{ii}.sl0');
        %disp(subprob{ii}.tl0');
        [x0,y0,lb,ub,~]=Upper_bound(c',d,Q,P,A,b,subprob{ii}.sl0,subprob{ii}.tl0,wl0,wu0,xub);
        if ~isempty(x0) && ~isempty(y0) 
            eta=P'*x0+c'; 
            xi=Q'*x0+d;
            subprob{ii}.dist=y0-eta./xi;
            subprob{ii}.ub = ub;
            subprob{ii}.y = y0;
            subprob{ii}.x = x0;
            subprob{ii}.w=eta./xi;
            v = lb;
%             fprintf('x%d%d',iter,ii);
%             disp(subprob{ii}.x');
%             fprintf('ub%d%d',iter,ii);
%             disp(subprob{ii}.ub);
       %% update lower bound
            if v > v_opt
                v_opt = v;
                x_opt = x0;
                y_opt = y0;
            end    
            AllNodes = [AllNodes,subprob{ii}];
        end
    end
    %% delete nodes
    if ~isempty(AllNodes)
        ii = 0;
        while ii < length(AllNodes)
            ii = ii+1;
            if AllNodes(ii).ub < v_opt - err
                AllNodes(ii) = [];
                ii = ii-1;
            end
        end
    end
    if isempty(AllNodes)
        fprintf(2,'AllNodes = empty!\n');
        break;
    else
        UB = AllNodes(1).ub;
        index_LB = 1;
        ii = 1;
        while ii < length(AllNodes)
            ii = ii+1;
            if AllNodes(ii).ub > UB
                UB = AllNodes(ii).ub;
                index_LB = ii;
            end
        end
        prob = AllNodes(index_LB);
        AllNodes(index_LB) = [];
    end
    if mod(iter,1) == 0 && print == 1
        fprintf(1,'Iter = %3d,  UB = %12.8f,  LB = %12.8f, gap = %5.2f%%\n',...
            iter,UB,v_opt,100*abs(v_opt-UB)/(1.0e-10+abs(v_opt)));
    end
%        fprintf(1,'%8d %8.5f %8.5f',...
%          iter,UB,v_opt);
end
x_opt = prob.x;
y_opt = prob.y;
% fprintf('x:');
% disp(prob.x');
time=toc(tstart);
if print == 1
    fprintf(1,'Iter = %3d,  UB = %12.8f,  LB = %12.8f, gap = %5.2f%%\n',...
        iter,UB,v_opt,100*(UB-v_opt)/(1.0e-10+abs(v_opt)));
end
fprintf( 'fval & iter &time\n');
fprintf('%.7f & %.1f & %.4f\n',v_opt,iter,time);
    % disp(roundn(prob.x',-5));
end