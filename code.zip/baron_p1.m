function [fval, time] = test_baron_p1(c,d,Q,P,A,b)
[n1, n2] = size(A);
[~, r] = size(P);
lb = [zeros(n2, 1)];
ub = [inf * ones(n2, 1)];
al = -inf * ones(n1, 1);
MaxTime = 3600;
EpsA = 1e-5;
EpsR = 1e-6;
opts = baronset('MaxTime',MaxTime,'EpsA',EpsA,'EpsR',EpsR);
fun = @(X)-ones(1, r) * ((P' * X(1 : n2) + c') ./ (Q' * X(1 : n2) + d));
[X, fval, ~, info, ~] = baron(fun, A, al, b, lb, ub, [], [], [], [], [], opts);
fval = -info.Upper_Bound;
time = info.Total_Time;
end

